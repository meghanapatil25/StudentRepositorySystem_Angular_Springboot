import { Component, OnInit, Input } from '@angular/core';
import { Activity } from '../model/Activity';
import { AuthenticationService } from '../authentication.service';
import { ActivityService } from '../activity.service';

@Component({
  selector: 'app-show-activities',
  templateUrl: './show-activities.component.html',
  styleUrls: ['./show-activities.component.css']
})
export class ShowActivitiesComponent implements OnInit {

  @Input() activityList: Activity[];
  AdminFlag : boolean= false;
  StudentFlag : boolean = false;

  constructor(private authService : AuthenticationService, private activityService:ActivityService) { 
    this.authService.getStudentDetail().subscribe(data=>{
      console.log(data.role);
      if(data.role=='Student'){
        this.StudentFlag = true;
        this.AdminFlag = false;
      }
      else if(data.role=='Admin'){
        this.AdminFlag = true;
        this.StudentFlag = false;
      }
    })
  }

  removeActivity(id:number){
    this.activityService.removeActivity(id).subscribe(response=>{
      this.activityService.getAllActivities().subscribe(resp=>{
        this.activityList=resp;
      }); 
    });
    
  }

  ngOnInit() {
  }

}
