import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Student } from '../model/Student';
import { AuthenticationService } from '../authentication.service';
import { Router } from "@angular/router";
import { StudentService } from '../student.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  invalidLogin: boolean = false;
  loginForm: FormGroup;

  student: Student = new Student();

  constructor(private formBuilder: FormBuilder, private router: Router, private authService: AuthenticationService, private studentService: StudentService) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    console.log(this.loginForm)
    if (this.loginForm.invalid == true) {
      console.log("invalid")
      return;
    }
    this.authService.login(this.loginForm.controls.username.value, this.loginForm.controls.password.value)
      .subscribe(response => {
        if (response) {
          if (response.role == 'Student') {
            // this.studentService.sendData(response);
            this.router.navigate(['/students']);
            this.authService.sendStudentDetail(response);

          } else
            if (response.role == 'Admin') {
              this.router.navigate(['/admin']);
              this.authService.sendStudentDetail(response);
            } else
              if (response.role == 'Superadmin') {
                this.router.navigate(['/superadmin']);
                this.authService.sendStudentDetail(response);
              }
        }
        else {
          alert('wrong user');
          this.loginForm.reset();
        }
      });
  }


}



