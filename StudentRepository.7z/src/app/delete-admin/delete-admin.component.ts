import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-delete-admin',
  templateUrl: './delete-admin.component.html',
  styleUrls: ['./delete-admin.component.css']
})
export class DeleteAdminComponent implements OnInit {
  deleteAdminForm: FormGroup;
  studentid: number;

  constructor(private studentService: StudentService,
    private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.deleteAdminForm = this.formBuilder.group(
      { studentid: ['', Validators.required] }
    )
  }

  onSubmit() {
    console.log(this.deleteAdminForm);

    if (this.deleteAdminForm.invalid == true) {
      console.log("Invalid");
      return;
    } else if (this.deleteAdminForm.controls) {
      this.studentid = this.deleteAdminForm.controls.studentid.value;
      this.studentService.deleteAdmin(this.studentid).subscribe(response => {
        console.log(response);
        if (response === true) {
          alert('Admin deleted successfully...');
          this.deleteAdminForm.reset();
        }
      },
        err => {
          alert('Invalid Admin Id');
          this.deleteAdminForm.reset();
        });
    }
  }
}
