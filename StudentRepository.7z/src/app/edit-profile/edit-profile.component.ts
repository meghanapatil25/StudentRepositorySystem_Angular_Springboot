import { Component, OnInit, Input } from '@angular/core';
import { Student } from '../model/Student';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StudentService } from '../student.service';
import { Response } from 'selenium-webdriver/http';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  @Input() student: Student;
  xyz: boolean = false;
  editStuForm: FormGroup;

  constructor(private formBuilder: FormBuilder,
    private studentService: StudentService) { }

  ngOnInit() {
    this.editStuForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
    });
  }

  onSubmit() {
    debugger
    console.log(this.editStuForm);
    if (this.editStuForm.invalid) {
      console.log("Invalid");
      return;
    } else {
      this.student.email = this.editStuForm.controls.email.value;
    }

    if (this.student.email) {
      debugger
      console.log(this.student.studentid);
      this.studentService.editStuProfile(this.student.email, this.student.studentid)
        .subscribe(response => {
          console.log(response);
          this.xyz = true;
        });
    }
  }

}
