export class Student {
    studentid: number;
    name: String;
    address: String;
    city: String;
    pincode: number;
    state: String;
    country: String;
    dob: String;
    age: number;
    email: String;
    mobile: String;
    gender: String;
    specialization: String;
    username: String;
    password: String;
    confirmPassword: String;
    role: String;
}
