export class Activity {
    actId: number;
    info: String;
    deadline: String;
}