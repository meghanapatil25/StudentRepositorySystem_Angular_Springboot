import { Component, OnInit, Input, Output } from '@angular/core';
import { EventEmitter } from 'events';
import { AuthenticationService } from '../authentication.service';
import { Student } from '../model/Student';
import { StudentService } from '../student.service';
import { Activity } from '../model/Activity';
import { ActivityService } from '../activity.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() name: string;
  @Output() changeName = new EventEmitter();
  public Role;
  student: Student;
  activity: Activity;
  studentid: number;
  studentList: Student[];
  activityList: Activity[];
  showStudent: boolean = false;
  showStudentList: boolean = false;
  editStudent: boolean = false;
  showDeleteStudentFlag: boolean = false;

  showAdmin: boolean;
  adminList: Student[];
  addNewAdminFlag: boolean = false;
  showDeleteAdminFlag: boolean = false;

  addActivity: boolean = false;
  showActivityFlagStu: boolean = false;
  showActivityFlagAdmin: boolean = false;

  constructor(private authService: AuthenticationService, private studentService: StudentService, private activityService: ActivityService) {
    this.authService.getStudentDetail().subscribe(data => {
      debugger
      if (data.role == 'Student') {
        this.Role = data.role;
        this.student = data;
        this.studentid = data.studentid;
        //  this.authService.sendStudentDetail(data);
      }
      if (data.role == 'Admin') {
        this.Role = data.role;
        this.student = data;
        //this.authService.sendStudentDetail(data);
      }
      if (data.role == 'Superadmin') {
        this.Role = data.role;
        this.student = data;
        //this.authService.sendStudentDetail(data);
      }
      console.log(data);
    });
  }

  //Superadmin module
  getAdminList() {
    this.studentService.getAdminList().subscribe(data => {
      this.adminList = data;
      this.showAdmin = true;
      this.addNewAdminFlag = false;
      this.showDeleteAdminFlag = false;
    });
  }

  addNewAdmin() {
    this.addNewAdminFlag = true;
    this.showAdmin = false;
    this.showDeleteAdminFlag = false;
  }

  showDeleteAdminPage() {
    this.showDeleteAdminFlag = true;
    this.showAdmin = false;
    this.addNewAdminFlag = false;
  }

  //admin module
  getStudentList() {
    debugger
    this.studentService.getStudentList().subscribe(data => {
      this.studentList = data;
      this.showStudentList = true;
      this.showDeleteStudentFlag = false;
      this.addActivity = false;
      this.showActivityFlagAdmin = false;
    })
  }

  showDeleteStudentPage() {
    this.showDeleteStudentFlag = true;
    this.showStudentList = false;
    this.addActivity = false;
    this.showActivityFlagAdmin = false;
  }

  addNewActivity() {
    this.addActivity = true;
    this.showDeleteStudentFlag = false;
    this.showStudentList = false;
    this.showActivityFlagAdmin = false;
  }

  showActivitiesForAdmin() {
    debugger
    this.activityService.getAllActivities().subscribe(data => {
      this.activityList = data;
      this.showActivityFlagAdmin = true;
      this.addActivity = false;
      this.showDeleteStudentFlag = false;
      this.showStudentList = false;
    })
  }

  //Student module
  getStudentDetail(id: number) {
    this.studentService.getStudentDetail(id).subscribe(data => {
      this.showStudent = true;
      this.editStudent = false;
      this.student = data;
      this.showActivityFlagStu = false;

    })
  }

  getStudentDetailforEdit(id: number) {
    this.studentService.getStudentDetail(id).subscribe(data => {
      this.showStudent = false;
      this.student = data;
      this.editStudent = true;
      this.showActivityFlagStu = false;
    })
  }

  showActivitiesForStudent() {
    debugger
    this.activityService.getAllActivities().subscribe(data => {
      this.activityList = data;
      this.showActivityFlagStu = true;
      this.showStudent = false;
      this.editStudent = false;
    })
  }



  ngOnInit() {

  }
}
