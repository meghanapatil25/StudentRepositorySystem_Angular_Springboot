import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivityService } from '../activity.service';
import { Activity } from '../model/Activity';

@Component({
  selector: 'app-add-activity',
  templateUrl: './add-activity.component.html',
  styleUrls: ['./add-activity.component.css']
})
export class AddActivityComponent implements OnInit {

  addActivityForm: FormGroup;
  //submitted: boolean = false;
  activity:Activity=new Activity();

  constructor(private activityService: ActivityService,
    private formBuilder: FormBuilder) {
      // this.activity=new Activity();
  }

  ngOnInit() {
    debugger
    this.addActivityForm = this.formBuilder.group({
      info: ['', Validators.required],
      deadline: ['', Validators.required]
    });
  }

  onSubmit() {
    debugger
    console.log(this.addActivityForm);
    if (this.addActivityForm.invalid == true) {
      console.log("Invalid");
      return;
    } else 
    if (this.addActivityForm.controls) {
      console.log(this.addActivityForm);

      this.activity.info = this.addActivityForm.controls.info.value;
      this.activity.deadline = this.addActivityForm.controls.deadline.value;

      if (this.activity) {
        //this.submitted = true;
        this.activityService.addActivity(this.activity).subscribe(data => console.log(data));

        alert('Activity Successfully Added...!');
        this.addActivityForm.reset();
      }
    }
  }

}
