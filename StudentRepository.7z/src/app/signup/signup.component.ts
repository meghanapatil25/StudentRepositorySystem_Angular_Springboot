import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Student } from '../model/Student';
import { StudentService } from '../student.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  registerForm: FormGroup;
  student: Student = new Student();
  submitted = false;
  //public today = new Date();


  constructor(private formBuilder: FormBuilder,
     private router: Router, 
     private studentService: StudentService) {

    // this.tomorrow.setDate(this.tomorrow.getDate() + 1);
  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      name: ['', Validators.required],
      address: ['', Validators.required],
      city: ['', Validators.required],
      pincode: ['', [Validators.required, Validators.pattern('[0-9]{6}')]],
      state: ['', Validators.required],
      country: ['', Validators.required],
      dob: ['', Validators.required],
      age: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern('[789][0-9]{9}')]],
      gender: ['', Validators.required],
      specialization: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    });
  }

  onSubmit() {
    console.log(this.registerForm);
    if (this.registerForm.invalid == true) {
      console.log("inavalid")
      return;
    } else
      if (this.registerForm.controls) {
        var form = this.registerForm.controls;
        this.student.name = form.name.value;
        this.student.address = form.address.value;
        this.student.city = form.city.value;
        this.student.pincode = form.pincode.value;
        this.student.state = form.state.value;
        this.student.country = form.country.value;
        this.student.dob = form.dob.value;
        this.student.age = form.age.value;
        this.student.email = form.email.value;
        this.student.mobile = form.mobile.value;
        this.student.gender = form.gender.value;
        this.student.specialization = form.specialization.value;
        this.student.username = form.username.value;
        this.student.password = form.password.value;
        this.student.confirmPassword = form.confirmPassword.value;

        if (this.student) {

          this.submitted = true;
          this.studentService.signUp(this.student)
            .subscribe(data => console.log(data));

          alert('Successfully Registered...!');
          this.router.navigate(['']);
        }
        // console.log(this.registerForm);
      }
  }
}
