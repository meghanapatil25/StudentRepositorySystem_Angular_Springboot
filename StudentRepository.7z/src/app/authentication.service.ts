import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { Student } from './model/Student';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  private baseUrl = 'http://localhost:8086/api/student';
  private stuDetailSubject = new BehaviorSubject(null);
  constructor(private http: HttpClient) { }

  login(username, password): Observable<any> {
    let params = new HttpParams();
    params = params.set('username', username);
    params = params.set('password', password);
    return this.http.get(`${this.baseUrl}` + `/find`, { params: params });
  }

  sendStudentDetail(data) {
    this.stuDetailSubject.next(data);
  }

  getStudentDetail() {
    return this.stuDetailSubject.asObservable();
  }
}
