import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { HeaderComponent } from './header/header.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { StudentComponent } from './student/student.component';
import { AdminComponent } from './admin/admin.component';
import { SuperAdminComponent } from './super-admin/super-admin.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AdminListComponent } from './admin-list/admin-list.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { StudentListComponent } from './student-list/student-list.component';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { DeleteStudentComponent } from './delete-student/delete-student.component';
import { DeleteAdminComponent } from './delete-admin/delete-admin.component';
import { AddActivityComponent } from './add-activity/add-activity.component';
import { ShowActivitiesComponent } from './show-activities/show-activities.component';

//search module
import { Ng2SearchPipeModule } from 'ng2-search-filter';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    WelcomeComponent,
    HeaderComponent,
    StudentComponent,
    AdminComponent,
    SuperAdminComponent,
    ViewProfileComponent,
    AdminListComponent,
    EditProfileComponent,
    StudentListComponent,
    AddAdminComponent,
    DeleteStudentComponent,
    DeleteAdminComponent,
    AddActivityComponent,
    ShowActivitiesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
    Ng2SearchPipeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
