import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-delete-student',
  templateUrl: './delete-student.component.html',
  styleUrls: ['./delete-student.component.css']
})
export class DeleteStudentComponent implements OnInit {
  deleteStudentForm : FormGroup;
  studentid:number;
  constructor(private formBuilder: FormBuilder,
    private studentService:StudentService) { }

  ngOnInit() {
    this.deleteStudentForm = this.formBuilder.group({
      studentid : ['', Validators.required]
    })
  }

  onSubmit(){
    console.log(this.deleteStudentForm);

    if(this.deleteStudentForm.invalid==true){
      console.log("Invalid");
      return;
    }else if(this.deleteStudentForm.controls){
      this.studentid = this.deleteStudentForm.controls.studentid.value;
      this.studentService.deleteStudent(this.studentid).subscribe(response=>{
        console.log(response);
        if(response===true){
          alert('Student deleted successfully...');
          this.deleteStudentForm.reset();
        }
      },err=>{
        alert('Invalid Student Id');
        this.deleteStudentForm.reset(); 
      });
    }
  }

}
