import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Activity } from './model/Activity';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ActivityService {

  private baseUrl = 'http://localhost:8086/api/student';
  
  constructor(private http:HttpClient) { }

  addActivity(activity : Activity) : Observable<Object>{
    return this.http.post(`${this.baseUrl}` + `/addActivity`, activity);
  }

  getAllActivities(){
    return this.http.get<Activity[]>(`${this.baseUrl}`+`/getActivityList`);
  }

  removeActivity(actId:number){
    return this.http.delete(`${this.baseUrl}`+`/deleteActivity/`+actId);
  }
}
