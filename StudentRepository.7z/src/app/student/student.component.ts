import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../model/Student';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  student : any = new Student();
  constructor(private studentService : StudentService, private route: Router) {
    
  }

  ngOnInit() {
    this.studentService.viewProfile().subscribe(data => {
      this.student = data;
    })
  }

  // goToViewProfile(){
  //   debugger
  //   this.route.navigate(['viewProfile'],this.student);
  // }

}
