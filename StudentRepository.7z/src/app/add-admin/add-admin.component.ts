import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StudentService } from '../student.service';
import { Student } from '../model/Student';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent implements OnInit {
  addAdminForm: FormGroup;
  student: Student = new Student();
  adminSubmitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private studentService: StudentService) { }

  ngOnInit() {
    debugger
    this.addAdminForm = this.formBuilder.group({
      name: ['', Validators.required],
      address: ['', Validators.required],
      city: ['', Validators.required],
      pincode: ['', [Validators.required, Validators.pattern('[0-9]{6}')]],
      state: ['', Validators.required],
      country: ['', Validators.required],
      dob: ['', Validators.required],
      age: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern('[789][0-9]{9}')]],
      gender: ['', Validators.required],
      specialization: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(10)]],
      confirmPassword: ['', Validators.required]
    });
  }

  onSubmit() {
    console.log(this.addAdminForm);
    debugger
    if (this.addAdminForm.invalid == true) {
      console.log("Invalid");
      return;
    }
    else
      if (this.addAdminForm.controls) {
        var form = this.addAdminForm.controls;
        this.student.name = form.name.value;
        this.student.address = form.address.value;
        this.student.city = form.city.value;
        this.student.pincode = form.pincode.value;
        this.student.state = form.state.value;
        this.student.country = form.country.value;
        this.student.dob = form.dob.value;
        this.student.age = form.age.value;
        this.student.email = form.email.value;
        this.student.mobile = form.mobile.value;
        this.student.gender = form.gender.value;
        this.student.specialization = form.specialization.value;
        this.student.username = form.username.value;
        this.student.password = form.password.value;
        this.student.confirmPassword = form.confirmPassword.value;
        if (this.student) {
          this.adminSubmitted = true;
          this.studentService.addAdmin(this.student).subscribe(data => {
            console.log(data);
          });
          alert('Admin Added Successfully...!');
          this.addAdminForm.reset();
        }
      }
  }

}
