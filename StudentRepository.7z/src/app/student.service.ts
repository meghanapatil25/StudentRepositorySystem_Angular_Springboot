import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Student } from './model/Student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private baseUrl = 'http://localhost:8086/api/student';
  newId;

  constructor(private http:HttpClient) { }

  // sendData(data){
  //   console.log("inside student data=>",data);
  //   this.newId = data;
  // }
  
  signUp(student: Student): Observable<Object>{
    return this.http.post(`${this.baseUrl}` + `/create`, student);
  }

  addAdmin(admin : Student):Observable<Object>{
    return this.http.post(`${this.baseUrl}` + `/addAdmin`, admin);
  }

  viewProfile(): Observable<Object>{
    return this.http.get(`${this.baseUrl}`+`/students/`+this.newId);
  }

  getAdminList(){
    return this.http.get<Student[]>(`${this.baseUrl}`+`/getAdminList`);
  }

  getStudentList(){
    return this.http.get<Student[]>(`${this.baseUrl}`+`/getStduentList`);
  }

  getStudentDetail(studentid:number){
    return this.http.get<Student>(`${this.baseUrl}`+`/getStudentDetail/`+studentid);
  }
  
  editStuProfile(email,studentid){
    let params = new HttpParams();
    params = params.set('email', email);
    params = params.set('studentid', studentid);
    return this.http.get(`${this.baseUrl}` + `/update`, { params: params });
  }

  deleteAdmin(studentid:number){
    return this.http.delete(`${this.baseUrl}`+`/deleteAdmin/`+studentid);
  }

  deleteStudent(studentid:number){
    return this.http.delete(`${this.baseUrl}`+`/deleteStudent/`+studentid);
  }
  
}
